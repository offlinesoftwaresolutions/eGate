package com.oss.egate.push

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

/** Finds the installed eGate and checks it is the real one, by package name and certificate. */
internal object EgateIdentity {

    /**
     * The eGate package to talk to: one of the pinned names, signed with the pinned key and
     * offering the registration service. Null when there is none.
     */
    fun trustedPackage(context: Context): String? {
        val pm = context.packageManager
        return EgatePushContract.EGATE_PACKAGES.firstOrNull { pkg ->
            isSignedByEgate(pm, pkg) && offersRegistration(pm, pkg)
        }
    }

    fun isTrusted(context: Context, packageName: String?): Boolean =
        packageName != null &&
            packageName in EgatePushContract.EGATE_PACKAGES &&
            isSignedByEgate(context.packageManager, packageName)

    private fun offersRegistration(pm: PackageManager, pkg: String): Boolean {
        val intent = Intent(EgatePushContract.ACTION_REGISTER).setPackage(pkg)
        return runCatching { pm.queryIntentServices(intent, 0).isNotEmpty() }.getOrDefault(false)
    }

    private fun isSignedByEgate(pm: PackageManager, pkg: String): Boolean = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // Follows key rotation, so a future eGate key rotated from this one still passes.
            pm.hasSigningCertificate(
                pkg,
                hexToBytes(EgatePushContract.EGATE_CERT_SHA256),
                PackageManager.CERT_INPUT_SHA256,
            )
        } else {
            @Suppress("DEPRECATION")
            val signatures = pm.getPackageInfo(pkg, PackageManager.GET_SIGNATURES).signatures
            !signatures.isNullOrEmpty() && signatures.all {
                sha256Hex(it.toByteArray()) == EgatePushContract.EGATE_CERT_SHA256
            }
        }
    } catch (e: PackageManager.NameNotFoundException) {
        false
    } catch (e: RuntimeException) {
        false
    }

    fun sha256Hex(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    fun hexToBytes(hex: String): ByteArray {
        val clean = hex.replace(":", "").lowercase()
        require(clean.length % 2 == 0) { "odd-length hex" }
        return ByteArray(clean.length / 2) { i ->
            clean.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }
}
