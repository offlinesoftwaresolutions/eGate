/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: C:\\Users\\Edwin\\Downloads\\commandlinetools-win-13114758_latest\\cmdline-tools\\bin\\sdk\\build-tools\\36.0.0\\aidl.exe -pC:\\Users\\Edwin\\Downloads\\commandlinetools-win-13114758_latest\\cmdline-tools\\bin\\sdk\\platforms\\android-37.0\\framework.aidl -oC:\\Users\\Edwin\\.t3\\worktrees\\eGate\\push-notifications\\egate-push-sdk\\build\\generated\\aidl_source_output_dir\\release\\out -IC:\\Users\\Edwin\\.t3\\worktrees\\eGate\\push-notifications\\egate-push-sdk\\src\\main\\aidl -IC:\\Users\\Edwin\\.t3\\worktrees\\eGate\\push-notifications\\egate-push-sdk\\src\\release\\aidl -dC:\\Users\\Edwin\\AppData\\Local\\Temp\\aidl1721461086683016652.d C:\\Users\\Edwin\\.t3\\worktrees\\eGate\\push-notifications\\egate-push-sdk\\src\\main\\aidl\\com\\oss\\egate\\push\\IEgatePushCallback.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package com.oss.egate.push;
/** eGate's answer to a token request. Exactly one of these is called, once. */
public interface IEgatePushCallback extends android.os.IInterface
{
  /** Default implementation for IEgatePushCallback. */
  public static class Default implements com.oss.egate.push.IEgatePushCallback
  {
    @Override public void onToken(java.lang.String token) throws android.os.RemoteException
    {
    }
    /** [code] is one of the EgatePushException codes. */
    @Override public void onError(int code, java.lang.String message) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements com.oss.egate.push.IEgatePushCallback
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an com.oss.egate.push.IEgatePushCallback interface,
     * generating a proxy if needed.
     */
    public static com.oss.egate.push.IEgatePushCallback asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof com.oss.egate.push.IEgatePushCallback))) {
        return ((com.oss.egate.push.IEgatePushCallback)iin);
      }
      return new com.oss.egate.push.IEgatePushCallback.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_onToken:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          this.onToken(_arg0);
          break;
        }
        case TRANSACTION_onError:
        {
          int _arg0;
          _arg0 = data.readInt();
          java.lang.String _arg1;
          _arg1 = data.readString();
          this.onError(_arg0, _arg1);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements com.oss.egate.push.IEgatePushCallback
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void onToken(java.lang.String token) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(token);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onToken, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      /** [code] is one of the EgatePushException codes. */
      @Override public void onError(int code, java.lang.String message) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(code);
          _data.writeString(message);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onError, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_onToken = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_onError = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "com.oss.egate.push.IEgatePushCallback";
  public void onToken(java.lang.String token) throws android.os.RemoteException;
  /** [code] is one of the EgatePushException codes. */
  public void onError(int code, java.lang.String message) throws android.os.RemoteException;
}
