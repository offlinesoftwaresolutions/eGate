package com.oss.egate.push

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import java.util.concurrent.Executor
import java.util.concurrent.Executors

/**
 * Subclass this and declare it in your manifest to receive eGate pushes:
 *
 * ```xml
 * <receiver
 *     android:name=".MyPushReceiver"
 *     android:exported="true"
 *     android:permission="com.oss.egate.permission.SEND_PUSH">
 *     <intent-filter>
 *         <action android:name="com.oss.egate.push.RECEIVE" />
 *     </intent-filter>
 * </receiver>
 * ```
 *
 * `android:permission` is what proves a broadcast came from eGate: only an app signed with
 * eGate's key can hold that permission. The receiver refuses to run without it.
 *
 * Both callbacks run on a background thread, one at a time. The system gives a broadcast
 * about ten seconds, so do quick work here and hand anything longer to WorkManager or a job.
 * Returning normally from [onMessage] tells eGate the message was delivered; throwing tells
 * it delivery failed.
 */
abstract class EgatePushReceiver : BroadcastReceiver() {

    /**
     * A data message. [data] holds exactly the key/value pairs your server sent. eGate may
     * deliver the same message more than once in rare cases; [messageId] is stable, so use
     * it to drop duplicates if that matters to you.
     */
    abstract fun onMessage(context: Context, messageId: String, data: Bundle)

    /** eGate learnt of a new token for this install. Send it to your server. */
    open fun onTokenRefresh(context: Context, token: String) {}

    final override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != EgatePushContract.ACTION_RECEIVE) return
        if (!isProtected(context) || !isFromEgate(context)) {
            if (isOrderedBroadcast) resultCode = EgatePushContract.RESULT_REJECTED
            return
        }
        val extras = intent.extras ?: Bundle()
        // Only ordered broadcasts carry a result; eGate sends messages ordered.
        val ordered = isOrderedBroadcast
        val pending = goAsync()
        executor.execute {
            var code = EgatePushContract.RESULT_DELIVERED
            try {
                when (extras.getString(EgatePushContract.EXTRA_EVENT)) {
                    EgatePushContract.EVENT_TOKEN ->
                        extras.getString(EgatePushContract.EXTRA_REGISTRATION_ID)
                            ?.let { onTokenRefresh(context, it) }
                    else -> {
                        val id = extras.getString(EgatePushContract.EXTRA_MESSAGE_ID)
                        if (id == null) {
                            code = EgatePushContract.RESULT_RECEIVER_ERROR
                        } else {
                            onMessage(context, id, dataOnly(extras))
                        }
                    }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "push handler threw", e)
                code = EgatePushContract.RESULT_RECEIVER_ERROR
            } finally {
                if (ordered) pending.resultCode = code
                pending.finish()
            }
        }
    }

    /**
     * Without `android:permission` on the receiver, any app could send to it. Refusing to
     * run is safer than trusting a forged message, and the log tells the developer why.
     */
    private fun isProtected(context: Context): Boolean {
        val permission = try {
            context.packageManager.getReceiverInfo(ComponentName(context, javaClass), 0).permission
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
        if (permission != EgatePushContract.PERMISSION_SEND_PUSH) {
            Log.e(
                TAG,
                "${javaClass.name} must declare android:permission=\"" +
                    "${EgatePushContract.PERMISSION_SEND_PUSH}\"; ignoring the broadcast",
            )
            return false
        }
        return true
    }

    /**
     * The permission already proves the sender. On Android 14+ eGate also shares its identity
     * with the broadcast, so check that it is one of the pinned eGate packages as well.
     */
    private fun isFromEgate(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) return true
        val sender = sentFromPackage ?: return true
        val trusted = EgateIdentity.isTrusted(context, sender)
        if (!trusted) Log.w(TAG, "ignoring a push broadcast from $sender")
        return trusted
    }

    internal companion object {
        private const val TAG = "EgatePushReceiver"

        /** One thread for every receiver in the app, so callbacks never overlap. */
        private val executor: Executor = Executors.newSingleThreadExecutor { r ->
            Thread(r, "egate-push").apply { isDaemon = true }
        }

        /** The extras minus eGate's own `egate.*` keys: what the developer's server sent. */
        fun dataOnly(extras: Bundle): Bundle = Bundle(extras).apply {
            extras.keySet()
                .filter { it.startsWith(EgatePushContract.RESERVED_PREFIX) }
                .forEach(::remove)
        }
    }
}
