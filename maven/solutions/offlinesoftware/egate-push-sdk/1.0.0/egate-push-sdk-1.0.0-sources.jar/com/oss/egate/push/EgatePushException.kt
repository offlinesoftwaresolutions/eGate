package com.oss.egate.push

/** Why [EgatePush.getToken] could not produce a token. [code] is one of the constants below. */
class EgatePushException(val code: Int, message: String?) : Exception(message) {

    /** Whether asking again later can succeed without anything changing on the device. */
    val isRetryable: Boolean
        get() = code == NETWORK || code == SERVER || code == TIMEOUT || code == NOT_ENROLLED

    companion object {
        /** No trusted eGate is installed, or it is too old to offer push. */
        const val NOT_AVAILABLE = 1

        /** eGate could not be bound, or it disconnected before answering. */
        const val BIND_FAILED = 2

        /** eGate did not answer in time. */
        const val TIMEOUT = 3

        /** The device has not finished enrolling with the server yet. */
        const val NOT_ENROLLED = 4

        /** The server does not know this package as an app-store developer app. */
        const val NOT_STORE_APP = 5

        /** This build is signed with a certificate the app store has not pinned. */
        const val SIGNER_MISMATCH = 6

        /** No network, or the server could not be reached. */
        const val NETWORK = 7

        /** The server answered with an error. */
        const val SERVER = 8

        /** eGate refused the caller's identity. */
        const val CALLER_REJECTED = 9

        /** Anything else. */
        const val INTERNAL = 10
    }
}
