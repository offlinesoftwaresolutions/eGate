package com.oss.egate.push

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.RemoteException
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Entry point for apps: is eGate push available on this device, and what is this install's
 * push token (its registration ID).
 *
 * The token identifies this installation of the app on this device. Send it to your own
 * server, which passes it to `POST /api/push/send` to reach this install. It survives app
 * updates and changes when the app is reinstalled; [EgatePushReceiver.onTokenRefresh] tells
 * you when eGate learns of a new one.
 */
object EgatePush {

    private const val TAG = "EgatePush"

    /** How long to wait for eGate, which may have to call the server first. */
    private const val TOKEN_TIMEOUT_MS = 60_000L

    fun interface TokenCallback {
        /** Exactly one of [token] or [error] is non-null. Called on the main thread. */
        fun onResult(token: String?, error: EgatePushException?)
    }

    /**
     * Whether a genuine eGate offering push is installed. Cheap: only the package manager is
     * asked. True does not promise that [getToken] will succeed, because the device may not
     * be enrolled yet or the app may not be in the store.
     */
    @JvmStatic
    fun isAvailable(context: Context): Boolean = EgateIdentity.trustedPackage(context) != null

    /**
     * Asks eGate for this install's token. Asynchronous; [callback] runs on the main thread.
     * Safe to call on every app start: eGate caches the token and only calls the server when
     * the install has changed.
     */
    @JvmStatic
    fun getToken(context: Context, callback: TokenCallback) {
        val appContext = context.applicationContext
        val main = Handler(Looper.getMainLooper())
        val egate = EgateIdentity.trustedPackage(appContext)
        if (egate == null) {
            main.post {
                callback.onResult(
                    null,
                    EgatePushException(EgatePushException.NOT_AVAILABLE, "eGate is not installed"),
                )
            }
            return
        }
        TokenRequest(appContext, egate, main, callback).start()
    }

    /** One bind, one call, one answer, then unbind. */
    private class TokenRequest(
        private val context: Context,
        private val egatePackage: String,
        private val main: Handler,
        private val callback: TokenCallback,
    ) : ServiceConnection {

        private val done = AtomicBoolean(false)
        private val timeout = Runnable {
            finish(null, EgatePushException(EgatePushException.TIMEOUT, "eGate did not answer"))
        }

        fun start() {
            val intent = Intent(EgatePushContract.ACTION_REGISTER).setPackage(egatePackage)
            val bound = try {
                context.bindService(intent, this, Context.BIND_AUTO_CREATE)
            } catch (e: SecurityException) {
                Log.w(TAG, "bind refused", e)
                false
            }
            if (!bound) {
                // A failed bindService still has to be balanced by an unbind.
                runCatching { context.unbindService(this) }
                done.set(true)
                main.post {
                    callback.onResult(
                        null,
                        EgatePushException(EgatePushException.BIND_FAILED, "could not bind to eGate"),
                    )
                }
                return
            }
            main.postDelayed(timeout, TOKEN_TIMEOUT_MS)
        }

        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            // The intent named the package, but check what actually answered.
            if (name.packageName != egatePackage) {
                finish(null, EgatePushException(EgatePushException.NOT_AVAILABLE, "unexpected service"))
                return
            }
            try {
                IEgatePushService.Stub.asInterface(binder).getToken(
                    context.packageName,
                    object : IEgatePushCallback.Stub() {
                        override fun onToken(token: String?) {
                            if (token.isNullOrBlank()) {
                                finish(null, EgatePushException(EgatePushException.INTERNAL, "empty token"))
                            } else {
                                finish(token, null)
                            }
                        }

                        override fun onError(code: Int, message: String?) {
                            finish(null, EgatePushException(code, message))
                        }
                    },
                )
            } catch (e: RemoteException) {
                finish(null, EgatePushException(EgatePushException.BIND_FAILED, e.message))
            }
        }

        override fun onServiceDisconnected(name: ComponentName) {
            finish(null, EgatePushException(EgatePushException.BIND_FAILED, "eGate disconnected"))
        }

        override fun onNullBinding(name: ComponentName) {
            finish(null, EgatePushException(EgatePushException.NOT_AVAILABLE, "eGate refused the bind"))
        }

        private fun finish(token: String?, error: EgatePushException?) {
            if (!done.compareAndSet(false, true)) return
            main.removeCallbacks(timeout)
            main.post {
                runCatching { context.unbindService(this) }
                callback.onResult(token, error)
            }
        }
    }
}
