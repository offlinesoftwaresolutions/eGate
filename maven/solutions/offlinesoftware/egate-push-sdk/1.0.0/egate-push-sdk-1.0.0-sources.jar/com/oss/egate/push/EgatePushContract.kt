package com.oss.egate.push

/**
 * The wire contract between eGate and apps using this SDK: actions, extras and result codes.
 * eGate compiles against this same file, so the two sides cannot drift apart.
 *
 * App code does not need any of this; use [EgatePush] and [EgatePushReceiver].
 */
object EgatePushContract {

    /** The protocol version eGate reports from `IEgatePushService.getVersion()`. */
    const val PROTOCOL_VERSION = 1

    /** Bind action of eGate's registration service. */
    const val ACTION_REGISTER = "com.oss.egate.push.REGISTER"

    /** Broadcast action eGate sends to the app's [EgatePushReceiver]. */
    const val ACTION_RECEIVE = "com.oss.egate.push.RECEIVE"

    /**
     * Signature permission defined by eGate. The app's receiver requires it of the sender,
     * so only eGate (signed with eGate's key) can deliver to it.
     */
    const val PERMISSION_SEND_PUSH = "com.oss.egate.permission.SEND_PUSH"

    /**
     * Every package name eGate ships under. Different flavours, one signing key.
     */
    val EGATE_PACKAGES: List<String> = listOf("com.oss.egate", "com.android.cts.egate")

    /** SHA-256 of eGate's signing certificate, lowercase hex without colons. */
    const val EGATE_CERT_SHA256 =
        "011ec5c06a0271d9018c191795fed0e6324d579686a92bf6391b82f5ebab119c"

    /** Prefix of every extra eGate adds. Server-side data keys may not use it. */
    const val RESERVED_PREFIX = "egate."

    /** What a [ACTION_RECEIVE] broadcast carries: [EVENT_MESSAGE] or [EVENT_TOKEN]. */
    const val EXTRA_EVENT = "egate.event"
    const val EVENT_MESSAGE = "message"
    const val EVENT_TOKEN = "token"

    const val EXTRA_MESSAGE_ID = "egate.message_id"
    const val EXTRA_REGISTRATION_ID = "egate.registration_id"

    /** Ordered-broadcast result: the receiver handled the message. */
    const val RESULT_DELIVERED = -1 // Activity.RESULT_OK

    /** Ordered-broadcast result: nothing answered. eGate passes this as the initial code. */
    const val RESULT_UNHANDLED = 0

    /** Ordered-broadcast result: the app's handler threw. */
    const val RESULT_RECEIVER_ERROR = 2

    /** Ordered-broadcast result: the receiver refused the broadcast as not from eGate. */
    const val RESULT_REJECTED = 3
}
