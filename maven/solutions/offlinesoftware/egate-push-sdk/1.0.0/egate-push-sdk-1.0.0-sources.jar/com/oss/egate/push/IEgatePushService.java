/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: C:\\Users\\Edwin\\Downloads\\commandlinetools-win-13114758_latest\\cmdline-tools\\bin\\sdk\\build-tools\\36.0.0\\aidl.exe -pC:\\Users\\Edwin\\Downloads\\commandlinetools-win-13114758_latest\\cmdline-tools\\bin\\sdk\\platforms\\android-37.0\\framework.aidl -oC:\\Users\\Edwin\\.t3\\worktrees\\eGate\\push-notifications\\egate-push-sdk\\build\\generated\\aidl_source_output_dir\\release\\out -IC:\\Users\\Edwin\\.t3\\worktrees\\eGate\\push-notifications\\egate-push-sdk\\src\\main\\aidl -IC:\\Users\\Edwin\\.t3\\worktrees\\eGate\\push-notifications\\egate-push-sdk\\src\\release\\aidl -dC:\\Users\\Edwin\\AppData\\Local\\Temp\\aidl12284237361906217821.d C:\\Users\\Edwin\\.t3\\worktrees\\eGate\\push-notifications\\egate-push-sdk\\src\\main\\aidl\\com\\oss\\egate\\push\\IEgatePushService.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package com.oss.egate.push;
/**
 * Bound with action com.oss.egate.push.REGISTER. eGate identifies the caller from the binder
 * calling uid; [packageName] only picks one package when several share that uid.
 */
public interface IEgatePushService extends android.os.IInterface
{
  /** Default implementation for IEgatePushService. */
  public static class Default implements com.oss.egate.push.IEgatePushService
  {
    /** Protocol version of the eGate side, so the SDK can adapt to older builds. */
    @Override public int getVersion() throws android.os.RemoteException
    {
      return 0;
    }
    @Override public void getToken(java.lang.String packageName, com.oss.egate.push.IEgatePushCallback callback) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements com.oss.egate.push.IEgatePushService
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an com.oss.egate.push.IEgatePushService interface,
     * generating a proxy if needed.
     */
    public static com.oss.egate.push.IEgatePushService asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof com.oss.egate.push.IEgatePushService))) {
        return ((com.oss.egate.push.IEgatePushService)iin);
      }
      return new com.oss.egate.push.IEgatePushService.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_getVersion:
        {
          int _result = this.getVersion();
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_getToken:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          com.oss.egate.push.IEgatePushCallback _arg1;
          _arg1 = com.oss.egate.push.IEgatePushCallback.Stub.asInterface(data.readStrongBinder());
          this.getToken(_arg0, _arg1);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements com.oss.egate.push.IEgatePushService
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /** Protocol version of the eGate side, so the SDK can adapt to older builds. */
      @Override public int getVersion() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getVersion, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void getToken(java.lang.String packageName, com.oss.egate.push.IEgatePushCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(packageName);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getToken, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_getVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_getToken = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "com.oss.egate.push.IEgatePushService";
  /** Protocol version of the eGate side, so the SDK can adapt to older builds. */
  public int getVersion() throws android.os.RemoteException;
  public void getToken(java.lang.String packageName, com.oss.egate.push.IEgatePushCallback callback) throws android.os.RemoteException;
}
